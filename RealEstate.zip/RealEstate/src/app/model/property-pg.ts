export class PropertyPG {
    propertyPGID:any; 
    propertyPGName:any; 	
    location:any;
    userAgent1ID:any;
    userAgent2ID:any;
}
