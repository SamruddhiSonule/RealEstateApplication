export class UserDTO {

    userAgent1ID:any;
	userAgent2ID:any; 
	userAgentName:any;
	userAgentEmail:any; 
	userAgentPassword:any; 
	userAgentContact:any; 
	userAgentAddress:any; 
    typeOfDeals:any;
	typeOfResidentialProperties:any;
	operatingSince:any;
	expertiseIn:any;
	descriptionOfBusiness:any;
	canProvidesLoan:any;
	localTime:any; 
    localDate:any; 
	userType:any;
}
