export class UserBuyerDTO {

    userBuyer1ID:any;
	userBuyer2ID:any;
	userBuyerName:any;
    userBuyerEmail:any;
	userBuyerPassword:any;
	userBuyerContact:any;
	userBuyerAddress:any;
	localTime:any;
	localDate:any;
	userType:any;
}
