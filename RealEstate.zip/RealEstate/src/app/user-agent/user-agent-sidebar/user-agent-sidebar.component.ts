import { Component } from '@angular/core';

@Component({
  selector: 'app-user-agent-sidebar',
  templateUrl: './user-agent-sidebar.component.html',
  styleUrl: './user-agent-sidebar.component.css'
})
export class UserAgentSidebarComponent {

}
