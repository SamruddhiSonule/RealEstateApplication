import { Component } from '@angular/core';

@Component({
  selector: 'app-user-agent-dashboard',
  templateUrl: './user-agent-dashboard.component.html',
  styleUrl: './user-agent-dashboard.component.css'
})
export class UserAgentDashboardComponent {

}
