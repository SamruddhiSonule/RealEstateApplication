import { Component } from '@angular/core';

@Component({
  selector: 'app-linkpages',
  templateUrl: './linkpages.component.html',
  styleUrl: './linkpages.component.css'
})
export class LinkpagesComponent {

}
