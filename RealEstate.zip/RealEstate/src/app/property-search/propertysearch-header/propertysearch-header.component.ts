import { Component } from '@angular/core';

@Component({
  selector: 'app-propertysearch-header',
  templateUrl: './propertysearch-header.component.html',
  styleUrl: './propertysearch-header.component.css'
})
export class PropertysearchHeaderComponent {

}
