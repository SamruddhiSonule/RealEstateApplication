import { Component } from '@angular/core';

@Component({
  selector: 'app-signup-footer',
  templateUrl: './signup-footer.component.html',
  styleUrl: './signup-footer.component.css'
})
export class SignupFooterComponent {

}
