import { Component } from '@angular/core';

@Component({
  selector: 'app-login-footer',
  templateUrl: './login-footer.component.html',
  styleUrl: './login-footer.component.css'
})
export class LoginFooterComponent {

}
