import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-addproperties',
  templateUrl: './user-owner-addproperties.component.html',
  styleUrl: './user-owner-addproperties.component.css'
})
export class UserOwnerAddpropertiesComponent {

}
