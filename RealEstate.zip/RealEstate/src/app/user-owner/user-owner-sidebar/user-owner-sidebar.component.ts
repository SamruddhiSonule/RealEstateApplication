import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-sidebar',
  templateUrl: './user-owner-sidebar.component.html',
  styleUrl: './user-owner-sidebar.component.css'
})
export class UserOwnerSidebarComponent {

}
