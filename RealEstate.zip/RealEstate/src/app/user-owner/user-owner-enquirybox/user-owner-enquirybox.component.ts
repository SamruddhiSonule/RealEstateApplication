import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-enquirybox',
  templateUrl: './user-owner-enquirybox.component.html',
  styleUrl: './user-owner-enquirybox.component.css'
})
export class UserOwnerEnquiryboxComponent {

}
