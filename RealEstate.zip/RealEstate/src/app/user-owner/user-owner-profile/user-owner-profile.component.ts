import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-profile',
  templateUrl: './user-owner-profile.component.html',
  styleUrl: './user-owner-profile.component.css'
})
export class UserOwnerProfileComponent {

}
