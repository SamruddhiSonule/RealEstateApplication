import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-analytics',
  templateUrl: './user-owner-analytics.component.html',
  styleUrl: './user-owner-analytics.component.css'
})
export class UserOwnerAnalyticsComponent {

}
