import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-dashboard',
  templateUrl: './user-owner-dashboard.component.html',
  styleUrl: './user-owner-dashboard.component.css'
})
export class UserOwnerDashboardComponent {

}
