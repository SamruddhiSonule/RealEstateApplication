import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-editprofile',
  templateUrl: './user-owner-editprofile.component.html',
  styleUrl: './user-owner-editprofile.component.css'
})
export class UserOwnerEditprofileComponent {

}
