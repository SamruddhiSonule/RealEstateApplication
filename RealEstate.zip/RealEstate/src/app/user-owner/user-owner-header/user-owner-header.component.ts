import { Component } from '@angular/core';

@Component({
  selector: 'app-user-owner-header',
  templateUrl: './user-owner-header.component.html',
  styleUrl: './user-owner-header.component.css'
})
export class UserOwnerHeaderComponent {

}
