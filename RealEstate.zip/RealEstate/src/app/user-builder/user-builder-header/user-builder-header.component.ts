import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-header',
  templateUrl: './user-builder-header.component.html',
  styleUrl: './user-builder-header.component.css'
})
export class UserBuilderHeaderComponent {

}
