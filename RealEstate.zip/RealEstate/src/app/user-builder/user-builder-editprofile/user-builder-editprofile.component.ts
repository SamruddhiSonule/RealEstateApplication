import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-editprofile',
  templateUrl: './user-builder-editprofile.component.html',
  styleUrl: './user-builder-editprofile.component.css'
})
export class UserBuilderEditprofileComponent {

}
