import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-analytics',
  templateUrl: './user-builder-analytics.component.html',
  styleUrl: './user-builder-analytics.component.css'
})
export class UserBuilderAnalyticsComponent {

}
