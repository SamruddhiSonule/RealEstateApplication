import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-sidebar',
  templateUrl: './user-builder-sidebar.component.html',
  styleUrl: './user-builder-sidebar.component.css'
})
export class UserBuilderSidebarComponent {

}
