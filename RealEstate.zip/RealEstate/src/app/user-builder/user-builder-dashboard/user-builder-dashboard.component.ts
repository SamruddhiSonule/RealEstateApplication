import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-dashboard',
  templateUrl: './user-builder-dashboard.component.html',
  styleUrl: './user-builder-dashboard.component.css'
})
export class UserBuilderDashboardComponent {

}
