import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-profile',
  templateUrl: './user-builder-profile.component.html',
  styleUrl: './user-builder-profile.component.css'
})
export class UserBuilderProfileComponent {

}
