import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-enquirybox',
  templateUrl: './user-builder-enquirybox.component.html',
  styleUrl: './user-builder-enquirybox.component.css'
})
export class UserBuilderEnquiryboxComponent {

}
