import { Component } from '@angular/core';

@Component({
  selector: 'app-user-builder-addproperties',
  templateUrl: './user-builder-addproperties.component.html',
  styleUrl: './user-builder-addproperties.component.css'
})
export class UserBuilderAddpropertiesComponent {

}
