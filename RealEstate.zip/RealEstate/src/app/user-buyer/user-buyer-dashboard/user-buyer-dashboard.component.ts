import { Component } from '@angular/core';

@Component({
  selector: 'app-user-buyer-dashboard',
  templateUrl: './user-buyer-dashboard.component.html',
  styleUrl: './user-buyer-dashboard.component.css'
})
export class UserBuyerDashboardComponent {

}
