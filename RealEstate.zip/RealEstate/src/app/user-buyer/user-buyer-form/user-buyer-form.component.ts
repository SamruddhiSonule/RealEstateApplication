import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-user-buyer-form',
  templateUrl: './user-buyer-form.component.html',
  styleUrl: './user-buyer-form.component.css'
})
export class UserBuyerFormComponent implements OnInit{

  alreadyProfileSetup:boolean;
  constructor(private fb:FormBuilder){}
  user
  ngOnInit(): void {
      
  }
}//
